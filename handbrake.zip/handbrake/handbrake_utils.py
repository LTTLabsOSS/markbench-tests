"""Utility functions for Handbrake test script"""
import re
import os
from zipfile import ZipFile
import requests
import logging
import shutil
from argparse import ArgumentParser
from pathlib import Path



script_dir = os.path.dirname(os.path.realpath(__file__))
EXECUTABLE = "HandBrakeCLI.exe"
HANDBRAKE_ZIP_NAME = "HandBrakeCLI-1.7.1-win-x86_64.zip"
SCORE_PATTERN = re.compile(r"avg (\d+\.\d+) fps,")
ABS_EXECUTABLE_PATH = os.path.join(script_dir, EXECUTABLE)

TEST_OPTIONS = {
    "CPU_H.264": f"--preset-import-file \"{script_dir}\\CPU_H.264\"-Z \"Fast 2160p60 4K H.264\"", #Custom Profile
    "CPU_H.265": "-Z \"Fast 2160p60 4K HEVC\"",
    "CPU_AV1": "-Z \"Fast 2160p60 4K AV1\"",
    "NVIDIA_H.264": f"--preset-import-file \"{script_dir}\\NVENC_H.264.json\" -Z \"H.264 NVENC 2160p 4K\"", #Custom Profile
    "NVIDIA_H.265": "-Z \"H.265 NVENC 2160p 4K\"",
    "NVIDIA_AV1": f"--preset-import-file \"{script_dir}\\NVENC_AV1.json\" -Z \"AV1 NVENC 2160p 4K\"", #Custom Profile
    "AMD_H.264": f"--preset-import-file \"{script_dir}\\AMD_H.264.json\" -Z \"H.264 VCN 2160p 4K\"", #Custom Profile
    "AMD_H.265": "-Z \"H.265 VCN 2160p 4K\"",
    "AMD_AV1": f"--preset-import-file \"{script_dir}\\AMD_AV1.json\" -Z \"AV1 VCN 2160p 4K\"", #Custom Profile
    "Intel_H.264": f"--preset-import-file \"{script_dir}\\Intel_H.264.json\" -Z \"H.264 QSV 2160p 4K\"", #Custom Profile
    "Intel_H.265": "-Z \"H.265 QSV 2160p 4K\"",
    "Intel_AV1": "-Z \"AV1 QSV 2160p 4K\"",
}



VIDEO_OPTIONS = {
    "1080P": "TQ - DLSS 3.0 Explained (1080p).mp4",
    "4K": "TQ - DLSS 3.0 Explained (4K).mp4",
}

parser = ArgumentParser()
parser.add_argument(
    "-Z", "--test_options", dest="test", help="Handbrake test type", required=True, choices=TEST_OPTIONS.keys())
parser.add_argument(
    "-i", "--video_options", dest="video", help="Handbrake video type", required=True, choices=VIDEO_OPTIONS.keys())
args = parser.parse_args()



VIDEO_PATH = os.path.join(script_dir, VIDEO_OPTIONS[args.video])
PROCESS_FILES = Path(r"\\Labs\labs\03_ProcessingFiles\Handbrake Test")
PROCESS_FILES_PATH = os.path.join(PROCESS_FILES, VIDEO_OPTIONS[args.video])


def get_score(output: str) -> str | None:
    """Finds score pattern from output string"""
    for line in reversed(output.splitlines()):
        match = SCORE_PATTERN.search(line)
        if match:
            return match.group(1)

    return None



def handbrakecli_exists() -> bool:
    """Check if HandbrakeCLI has been downloaded or not"""
    return os.path.isfile(ABS_EXECUTABLE_PATH)


def VIDEO_OPTIONS_CHECK() -> bool:
    """Check if the video file has been downloaded or not"""
    return os.path.isfile(VIDEO_OPTIONS[args.video])



def download_handbrakecli():
    """Download and extract HandbrakeCLI"""
    download_url = "https://github.com/HandBrake/HandBrake/releases/download/1.7.1/HandBrakeCLI-1.7.1-win-x86_64.zip"
    logging.info(handbrakecli_exists())
    logging.info(f"{ABS_EXECUTABLE_PATH} not found, downloading from %s", download_url)
    destination = os.path.join(script_dir, HANDBRAKE_ZIP_NAME)
    response = requests.get(download_url, allow_redirects=True, timeout=180)
    with open(destination, 'wb') as file:
        file.write(response.content)
    with ZipFile(destination, 'r') as zip_object:
        zip_object.extractall(path=script_dir)

def copy_test_files() -> None:
    try:
        src_path = f"{PROCESS_FILES_PATH}"
        dest_path = script_dir
        logging.info("Copying: %s -> %s", src_path, dest_path)
        shutil.copy(src_path, dest_path)
    except OSError as err:
        logging.error("Could not copy test file.")
        raise err