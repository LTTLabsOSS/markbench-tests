# Handbrake

Runs a single encode of Handbrake and reads the average encode FPS result from the output.

## Prerequisites

- Python 3.10+

## Options

- `-Z` Specifies the encoder to run in the Handbrake CLI. Chooses the preset to encode with.
- `-i` Specifies the video file to use in the Handbrake CLI. Chooses the preset to encode with.

## Output

report.json
- `test`: The name of the selected test
- `Average encoding FPS`: The encoding FPS average output by Handbrake
- `start_time`: number representing a timestamp of the test's start time in milliseconds
- `end_time`: number representing a timestamp of the test's end time in milliseconds