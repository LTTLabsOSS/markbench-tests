"""Handbrake test script"""
from argparse import ArgumentParser
import logging
from pathlib import Path
import subprocess
import sys
import os
import time
import psutil
from handbrake_utils import get_score, download_handbrakecli, handbrakecli_exists, VIDEO_OPTIONS_CHECK, copy_test_files

PARENT_DIR = str(Path(sys.path[0], ".."))
sys.path.append(PARENT_DIR)

from harness_utils.output import (
    DEFAULT_DATE_FORMAT,
    DEFAULT_LOGGING_FORMAT,
    seconds_to_milliseconds,
    write_report_json
)

script_dir = os.path.dirname(os.path.realpath(__file__))
log_dir = os.path.join(script_dir, "run")
if not os.path.isdir(log_dir):
    os.mkdir(log_dir)
LOGGING_FORMAT = '%(asctime)s %(levelname)-s %(message)s'
logging.basicConfig(filename=f'{log_dir}/harness.log',
                    format=LOGGING_FORMAT,
                    datefmt='%m-%d %H:%M',
                    level=logging.DEBUG)
console = logging.StreamHandler()
formatter = logging.Formatter(LOGGING_FORMAT)
console.setFormatter(formatter)
logging.getLogger('').addHandler(console)

EXECUTABLE = "HandBrakeCLI.exe"
PRESET_FILE = "presets.json"
ABS_EXECUTABLE_PATH = os.path.join(script_dir, EXECUTABLE)
PRESET_PATH = os.path.join(script_dir, PRESET_FILE)

TEST_OPTIONS = {
    "CPU_H.264": f"--preset-import-file \"{script_dir}\\CPU_H.264\"-Z \"Fast 2160p60 4K H.264\"", #Custom Profile
    "CPU_H.265": "-Z \"Fast 2160p60 4K HEVC\"",
    "CPU_AV1": "-Z \"Fast 2160p60 4K AV1\"",
    "NVIDIA_H.264": f"--preset-import-file \"{script_dir}\\NVENC_H.264.json\" -Z \"H.264 NVENC 2160p 4K\"", #Custom Profile
    "NVIDIA_H.265": "-Z \"H.265 NVENC 2160p 4K\"",
    "NVIDIA_AV1": f"--preset-import-file \"{script_dir}\\NVENC_AV1.json\" -Z \"AV1 NVENC 2160p 4K\"", #Custom Profile
    "AMD_H.264": f"--preset-import-file \"{script_dir}\\AMD_H.264.json\" -Z \"H.264 VCN 2160p 4K\"", #Custom Profile
    "AMD_H.265": "-Z \"H.265 VCN 2160p 4K\"",
    "AMD_AV1": f"--preset-import-file \"{script_dir}\\AMD_AV1.json\" -Z \"AV1 VCN 2160p 4K\"", #Custom Profile
    "Intel_H.264": f"--preset-import-file \"{script_dir}\\Intel_H.264.json\" -Z \"H.264 QSV 2160p 4K\"", #Custom Profile
    "Intel_H.265": "-Z \"H.265 QSV 2160p 4K\"",
    "Intel_AV1": "-Z \"AV1 QSV 2160p 4K\"",
}

VIDEO_OPTIONS = {
    "1080P": "TQ - DLSS 3.0 Explained (1080p).mp4",
    "4K": "TQ - DLSS 3.0 Explained (4K).mp4",
}



parser = ArgumentParser()
parser.add_argument(
    "-Z", "--test_options", dest="test", help="Handbrake test type", required=True, choices=TEST_OPTIONS.keys())
parser.add_argument(
    "-i", "--video_options", dest="video", help="Handbrake video type", required=True, choices=VIDEO_OPTIONS.keys())
args = parser.parse_args()




test_option = TEST_OPTIONS[args.test]
video_option = VIDEO_OPTIONS[args.video]
output = "myoutput.mp4"
VIDEO_PATH = os.path.join(script_dir, VIDEO_OPTIONS[args.video])
OUTPUT_PATH = os.path.join(log_dir, output)

command = f'\"{ABS_EXECUTABLE_PATH}\" {test_option} -i \"{VIDEO_PATH}\" -o \"{OUTPUT_PATH}\"'
command = command.rstrip()

try:
    setup_start_time = time.time()
    if handbrakecli_exists() is False:
        download_handbrakecli()

    if VIDEO_OPTIONS_CHECK() is False:
        copy_test_files()

    logging.info('Starting benchmark!')
    with subprocess.Popen(
        command,
        logging.info(command),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        universal_newlines=True) as proc:
        logging.info("Handbrake has started.")
        start_time = time.time()
        for line in proc.stdout:
            if "HandBrake 1.7.1" in line:
                elapsed_setup_time = round(time.time() - setup_start_time, 2)
                logging.info("Setup took %.2f seconds", elapsed_setup_time)
                logging.info("Setting HandbrakeCLI process priority to high (PID: %s)", proc.pid)
                process = psutil.Process(proc.pid)
                process.nice(psutil.HIGH_PRIORITY_CLASS)
                start_time = time.time()
                break
        out, _ = proc.communicate()
        logging.info(out)

        if proc.returncode > 0:
            logging.error("Handbrake exited with return code %d", proc.returncode)
            sys.exit(proc.returncode)

        score = get_score(out)
        if score is None:
            logging.error("Could not find average FPS output!")
            sys.exit(1)

        end_time = time.time()
        elapsed_test_time = round(end_time - start_time, 2)
        logging.info("Benchmark took %.2f seconds", elapsed_test_time)
        logging.info(f"Average encoding FPS was {score}")

        report = {
            "test": args.test,
            "video": args.video,
            "score": score,
            "start_time": seconds_to_milliseconds(start_time),
            "end_time": seconds_to_milliseconds(end_time)
        }

        write_report_json(log_dir, "report.json", report)
except Exception as e:
    logging.error("Something went wrong running the benchmark!")
    logging.exception(e)
    sys.exit(1)
